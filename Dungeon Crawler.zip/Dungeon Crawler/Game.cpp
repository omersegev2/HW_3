#include "Game.h"

// <<<<<<<<<<<<<<<<<<< HANDLE ACTIONS >>>>>>>>>>>>>>>>>>>>
void _handleCreate(std::istringstream &iss)
{
    std::string objectType;
    iss >> objectType;

    if (objectType == "Character")
    {
        std::string charName;
        int charHealth, charStrength, charDefense;
        iss >> charName >> charHealth >> charStrength >> charDefense;

        // Character c(charName.c_str(), charHealth, charStrength, charDefense);
    }
    else if (objectType == "Room")
    {
        std::string roomName;
        iss >> roomName;

        // Room room(roomName.c_str());
    }
    else if (objectType == "Item")
    {
        std::string itemName, roomName;
        int healthBonus, strengthBonus, defenseBonus;
        iss >> itemName >> roomName >> healthBonus >> strengthBonus >> defenseBonus;

        // Item item(itemName, healthBonus, strengthBonus, defenseBonus);
        // item.insertRoom(roomName);
    }
    else if (objectType == "Monster")
    {
        std::string monsterName, roomName;
        int health, strength, defense;
        iss >> monsterName >> roomName >> health >> strength >> defense;

        // Monster monster(monsterName.c_str(), health, strength, defense);
        // monster.insertRoom();
    }
    else
    {
        std::cout << "Unknown object type: " << objectType << std::endl;
    }
}

void _handleSet(std::istringstream &iss)
{
    //     std::string actionType, objectName;
    //     iss >> actionType >> objectName;

    //     if (actionType == "StartRoom")
    //     {
    //         Room *startRoom = findRoom(objectName.c_str());
    //         if (startRoom)
    //         {
    //             setStartRoom(startRoom);
    //         }
    //         else
    //         {
    //             std::cout << "Error: Room not found." << std::endl;
    //         }
    //     }
    //     else
    //     {
    //         std::cout << "Unknown action type: " << actionType << std::endl;
    //     }
}

void _handleAdd(std::istringstream &iss)
{
    // std::string actionType, objectName;
    // iss >> actionType >> objectName;

    // if (actionType == "Room")
    // {
    //     addRoom(new Room(objectName.c_str()));
    // }
    // else
    // {
    //     std::cout << "Unknown action type: " << actionType << std::endl;
    // }
}

void _handleConnect(std::istringstream &iss)
{
    // std::string room1, room2, direction;
    // iss >> room1 >> room2 >> direction;

    // Room *r1 = findRoom(room1.c_str());
    // Room *r2 = findRoom(room2.c_str());
    // if (r1 && r2)
    // {
    //     connectRooms(r1, r2, direction);
    // }
    // else
    // {
    //     std::cout << "Error: One or more rooms not found." << std::endl;
    // }
}

void _handlePlace(std::istringstream &iss)
{
    // std::string objectType, objectName, roomName;
    // int healthBonus, strengthBonus, defenseBonus;
    // iss >> objectType >> objectName >> roomName >> healthBonus >> strengthBonus >> defenseBonus;

    // Room *room = findRoom(roomName.c_str());
    // if (!room)
    // {
    //     std::cout << "Error: Room not found." << std::endl;
    //     return;
    // }

    // if (objectType == "Item")
    // {
    //     Item *item = new Item(objectName.c_str(), healthBonus, strengthBonus, defenseBonus);
    //     room->setItem(item);
    // }
    // else if (objectType == "Monster")
    // {
    //     Monster *monster = new Monster(objectName.c_str(), healthBonus, strengthBonus, defenseBonus);
    //     room->setMonster(monster);
    // }
    // else
    // {
    //     std::cout << "Unknown object type: " << objectType << std::endl;
    // }
}

void _handleEnter(std::istringstream &iss)
{
    // std::string charName;
    // iss >> charName;

    // Character *character = findCharacter(charName.c_str());
    // if (character)
    // {
    //     enterDungeon(character);
    // }
    // else
    // {
    //     std::cout << "Error: Character not found." << std::endl;
    // }
}

void _handleMove(std::istringstream &iss)
{
    // std::string charName, direction;
    // iss >> charName >> direction;

    // Character *character = findCharacter(charName.c_str());
    // if (character)
    // {
    //     moveCharacter(character, direction);
    // }
    // else
    // {
    //     std::cout << "Error: Character not found." << std::endl;
    // }
}

void _handleFight(std::istringstream &iss)
{
    // std::string charName, monsterName;
    // iss >> charName >> monsterName;

    // Character *character = findCharacter(charName.c_str());
    // Monster *monster = findMonster(monsterName.c_str());
    // if (character && monster)
    // {
    //     fight(character, monster);
    // }
    // else
    // {
    //     std::cout << "Error: Character or Monster not found." << std::endl;
    // }
}

void _handlePickUp(std::istringstream &iss)
{
    // std::string charName, itemName;
    // iss >> charName >> itemName;

    // Character *character = findCharacter(charName.c_str());
    // Item *item = findItem(itemName.c_str());
    // if (character && item)
    // {
    //     pickUpItem(character, item);
    // }
    // else
    // {
    //     std::cout << "Error: Character or Item not found." << std::endl;
    // }
}

// <<<<<<<<<<<<<<<<<<< ACTIONS >>>>>>>>>>>>>>>>>>>>
void Game::loadFromFile(const std::string &filename)
{
    std::ifstream file(filename);
    if (!file.is_open())
    {
        std::cerr << "Failed to open file: " << filename << std::endl;
        return;
    }

    std::string line;
    while (std::getline(file, line) && commandCount < MAX_COMMANDS)
    {
        if (!line.empty() && line.substr(0, 2) != "//")
        {
            commands[commandCount++] = line;
        }
    }
    file.close();
}

void Game::executeCommands()
{
    for (int i = 0; i < commandCount; i++)
    {
        std::istringstream iss(commands[i]);
        std::string commandType;

        iss >> commandType;
        
        std::cout << commandType << std::endl;

        if (commandType == "Create")
        {
            _handleCreate(iss);
        }
        else if (commandType == "Set")
        {
            _handleSet(iss);
        }
        else if (commandType == "Add")
        {
            _handleAdd(iss);
        }
        else if (commandType == "Connect")
        {
            _handleConnect(iss);
        }
        else if (commandType == "Place")
        {
            _handlePlace(iss);
        }
        else if (commandType == "Enter")
        {
            _handleEnter(iss);
        }
        else if (commandType == "Move")
        {
            _handleMove(iss);
        }
        else if (commandType == "Fight")
        {
            _handleFight(iss);
        }
        else if (commandType == "PickUp")
        {
            _handlePickUp(iss);
        }
        else
        {
            std::cout << "Unknown command: " << commandType << std::endl;
        }
    }
}

void Game::outputFinalState(const std::string &filename)
{
    std::cout << "OUT PUT FINAL STATE" << std::endl;
}
